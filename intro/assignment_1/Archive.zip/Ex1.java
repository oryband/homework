public class Ex1 {
    public static void main(String[] args) {
        for (int x=100; x>=1; x--) {
            System.out.println(x);
        }
    }
}
