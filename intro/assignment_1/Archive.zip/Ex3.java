public class Ex3 {
    public static void main(String[] args) {
    }
}
