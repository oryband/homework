public class Ex5 {
    public static void main(String[] args) {
    }
}
